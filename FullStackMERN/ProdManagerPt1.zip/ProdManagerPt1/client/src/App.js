import './App.css';
import React from 'react';
import Main from './views/Main';

function App() {
  return (
    <div className="">
      <Main />
    </div>
  );
}

export default App;
