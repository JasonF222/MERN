import React, { useEffect, useState } from 'react';
import EditForm from '../components/EditForm';

export default () => {
    
    return (
        <div>
            <EditForm />
        </div>
    )
}