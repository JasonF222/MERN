import React, { useEffect, useState } from 'react'
import ViewProduct from '../components/ViewProduct';

export default () => {
    return (
        <div>
            <ViewProduct />
        </div>
    )
}