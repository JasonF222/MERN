import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

export default (props) => {
    const [product, setProduct] = useState({});
    const { id } = useParams();

    useEffect(() => {
        axios.get('http://localhost:8000/api/products/view/' + id )
        .then(res => setProduct(res.data))
        .catch(err => console.log(err));
    }, []);

    return (
        <div>
            <p>Title: {product.title}</p><br/>
            <p>Price: {product.price}</p><br/>
            <p>Description: {product.description}</p><br/>

        </div>
    );
}