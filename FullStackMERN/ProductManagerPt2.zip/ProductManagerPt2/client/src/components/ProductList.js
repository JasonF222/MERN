import React from "react";
import axios from 'axios';
import { Link } from 'react-router-dom';

const ProductList = (props) => {
    return (
        <ul>
            {props.prodList.map((product, i) => <li key={i}> <Link to={"/products/view/" + product._id}> {product.title}</Link></li>)}
        </ul>
    )

}

export default ProductList;