import './App.css';
import ShowList from './components/ShowList';

function App() {
  return (
    <div className="">
      <ShowList />
    </div>
  );
}

export default App;
