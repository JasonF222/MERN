const domContainer = document.querySelector('#root');
const root = ReactDOM.createRoot(domContainer);
root.render(React.createElement("h1", {}, "Our First React page has rendered"));    

