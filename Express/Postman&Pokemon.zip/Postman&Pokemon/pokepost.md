<!-- Pokemon call # 1 -->

https://pokeapi.co/api/v2/pokemon/haunter

<!-- Pokemon call # 2 -->

https://pokeapi.co/api/v2/pokemon/charmander

<!-- Pokemon call # 3 -->

https://pokeapi.co/api/v2/pokemon/pikachu

<!-- Pokemon call # 4 -->

https://pokeapi.co/api/v2/pokemon/lucario

<!-- Pokemon call # 5 -->

https://pokeapi.co/api/v2/pokemon/snorlax